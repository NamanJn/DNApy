

def getHello(string):
	return "hello"	


def parseFasta(string):
	splitted = string.split(">")
	return splitted
					
